<template>
  <div id="app" style="padding: 8px">
  <router-view></router-view>   
  </div>
</template>
<script>
export default {
  watch: {
      '$route' (to, from) {
        console.log("from: " + from.path + " to: " + to.path)
      }},
}
</script>