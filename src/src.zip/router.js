import VueRouter from "vue-router";
import CollectionsPage from "./pages/collections/CollectionsPage"
import AddCardPage from "./pages/collections/AddCardPage"
import EditCardPage from "./pages/cards/EditCardPage"
import HomePage from "./pages/HomePage"

const router = new VueRouter({

  routes: [{
    path: '/collections/:id',
    component: CollectionsPage
  },{
    path: '/',
    component: HomePage
  },{
    path: '/collections/:id/add',
    component: AddCardPage
  }
  ,{
    path: '/cards/:id/edit',
    component: EditCardPage
  }
]
})

export default router