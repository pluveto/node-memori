import Axios from 'axios'
import qs from 'querystring'
var baseUrl = 'http://10.21.187.157:1323'
var urls = {    
    collections: baseUrl + '/collections',
    cards: baseUrl + '/cards'
}
export default {    
    getCollections: function (then) {
        Axios.get(urls.collections).then(function(response){
            then(response.data)
        })
    },
    getCollection: function (id, then) {
        Axios.get(urls.collections + "/" + id, ).then(function(response){
            then(response.data)
        })
    },
    addCollection: function (name, then){
        var bodyFormData = new FormData()
        bodyFormData.set('name', name)
        Axios.post(urls.collections, bodyFormData).then(then())
    },
    removeCollection: function(id){
        Axios.delete(urls.collections + "/" + id).then(function(){})
    },
    addCard(collectionId, card, then){
        var bodyFormData = new FormData()
        bodyFormData.set("collection_id", collectionId)
        bodyFormData.set("pos", card.pos)
        bodyFormData.set("spell", card.spell)
        bodyFormData.set("translation", card.translation)
        bodyFormData.set("addition", card.addition)
        Axios.post(urls.cards, bodyFormData).then((res)=>then(res.data))
    },
    getCards(collectionId, page, pageSize, then){
        var requestBody = {
            collection_id: collectionId,
            page: page,
            page_size: pageSize
        }
        Axios.get(urls.cards + '?' + qs.stringify(requestBody))
        .then((res)=>then(res.data))
    },
    getCard(id, then){
        Axios.get(urls.cards + '/' + id)
        .then((res)=>then(res.data))
    },
    removeCard(id){
        Axios.delete(urls.cards + "/" + id).then(function(){})
    },
    updateCard(card , then){
        var bodyFormData = new FormData()
        bodyFormData.set("collection_id", card.collection_id)
        bodyFormData.set("pos", card.pos)
        bodyFormData.set("spell", card.spell)
        bodyFormData.set("translation", card.translation)
        bodyFormData.set("addition", card.addition)
        Axios.put(urls.cards + "/" + card.id, bodyFormData).then((data)=>then(data))
    }

}