<style>
.center {
  text-align: center;
}
</style>
<template>
  <div class="container">
    <br />
    <h3 class="title is-3">{{collection.name}}</h3>
    <div class="control" style="float:right">
      <router-link
        :to="'/collections/'+collection.id+'/add'"
        class="button is-primary is-small"
        style="border-radius: 0"
      >添加卡片</router-link>
      <a class="button is-danger is-small" style="border-radius: 0" @click="deleteThis()">删除此集合</a>
    </div>
    <h4 class="title is-4">卡片</h4>
    <table class="table" style="width: 100%">
      <tr>
        <th style="width: 200px">拼写</th>
        <th>释义</th>
        <th style="width: 100px">熟练度</th>
        <th style="width: 100px">操作</th>
      </tr>

      <tr v-for="card in cards" v-bind:data="card" v-bind:key="card.id">
        <td>{{card.spell}}</td>
        <td>{{card.translation}}</td>
        <td>{{card.mastery}}</td>
        <td>
          <router-link :to="'/cards/' + card.id + '/edit'"
            class="button is-info is-small"
            style="border-radius: 0"
            @click="removeCard(card.id)"
          >E</router-link>
          <a
            class="button is-danger is-small"
            style="border-radius: 0"
            @click="removeCard(card.id)"
          >D</a>
        </td>
      </tr>
    </table>
    <div class="center">
      <p v-if="cards==null || cards.length == 0">集合里没有任何卡片.</p>
    </div>
  </div>
</template>
<script>
import back from "../../plugins/backend";
export default {
  data: function() {
    return {
      collection: {},
      cards: [],
      pagination: {
        current: 1,
        size: 10
      }
    };
  },
  created() {
    var vue = this;
    back.getCollection(this.$route.params.id, function(data) {
      vue.collection = data;
    });
    back.getCards(
      this.$route.params.id,
      this.pagination.current,
      this.pagination.size,
      data => {
        console.log("cards got: ", data);
        this.cards = data;
      }
    );
  },
  methods: {
    deleteThis() {
      var vue = this;
      this.$buefy.dialog.confirm({
        title: "删除集合",
        message: `你真的要删除这个卡片集合吗？无法反悔。`,
        confirmText: "删掉",
        cancelText: "别！",
        type: "is-danger",
        hasIcon: true,
        onConfirm: value => {
          back.removeCollection(vue.collection.id);
          this.$buefy.toast.open(`删除了卡册`);
          vue.$root.$store.commit("updateCollections", function() {
            vue.$router.push("/");
            console.log("back");
          });
        }
      });
    },
    removeCard(id) {
      var vue = this;
      this.$buefy.dialog.confirm({
        title: "删除卡片",
        message: `你真的要删除吗`,
        confirmText: "删掉",
        cancelText: "别！",
        type: "is-danger",
        hasIcon: true,
        onConfirm: value => {
          back.removeCard(id);
          vue.cards = vue.cards.filter(c => c.id != id);
          this.$buefy.toast.open(`删除了一张卡片`);
        }
      });
    }
  }
};
</script>
